# Pedimos el número de filas de la matriz
num_f = 0
while num_f < 1 :
  num_f = int( input('¿Cuántas filas quieres? ') )

# Pedimos el número de columnas de la matriz
num_c = 0
while num_c < 1 :
  num_c = int( input('¿Cuántas columnas quieres? ') )

# Pedimos los elementos de la primera matriz
print()
M1 = []
for f in range(0, num_f) :
  M1.append( [] )
  for c in range(0, num_c) :
    M1[f].append( float( input(f'Dame el elemento [{f}][{c}] de la 1a matriz: ') ) )

# Pedimos los elementos de la segunda matriz
print()
M2 = []
for f in range(0, num_f) :
  M2.append( [] )
  for c in range(0, num_c) :
    M2[f].append( float( input(f'Dame el elemento [{f}][{c}] de la 2a matriz: ') ) )

# Calculamos la matriz resultado sumando elementos de la primera y segunda matriz
MR = []
for f in range(0, num_f) :
  MR.append( [] )
  for c in range(0, num_c) :
    total = M1[f][c] + M2[f][c]
    MR[f].append( total )

# Imprimimos la matriz resultado
print()
for f in range(0, len(MR)) :
  print('| ', end='')
  for c in range(0, len(MR[f])) :
    print(f'{MR[f][c]:8.2f} ', end='')
  print('|')



'''
# Para multiplicar matrices sólo hace falta que el número de columnas
# de la primera matriz sea igual al número de filas de la segunda matriz.
# 
# La matriz resultado tendrá tantas filas como la primera matriz y 
# tantas columnas como la segunda matriz.
# 
# Cada elemento de la fila "f" y columna "c" de la matriz resultado, lo 
# calcularé realizando el producto escalar de la fila "f" de la primera 
# matriz por la columna "c" de la segunda matriz.

for f in range(0, num_f) :
  MR.append( [] )
  for c in range(0, num_c) :
    total = 0
    for k in range(0, len(M2)) :
      total = total + M1[f][k]*M2[k][c]
    MR[f].append( total )
'''
