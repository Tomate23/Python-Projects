# Pido el número de filas y columnas de la matriz

n = 0
while n < 3:
  n = int( input('¿Cuántas filas y columnas quieres? ') )

# Genero matriz de n*n ceros

Magica = [ [0] * n for f in range(n) ]



# RELLENA CUADRADO MÁGICO IMPAR

if (n % 2) != 0:
  f = 0
  c = n // 2
  aux = 1
  while aux <= n*n:
    Magica[f][c] = aux
    aux = aux + 1
    f_nou = (n-1 if f == 0   else f-1)
    c_nou = (0   if c == n-1 else c+1)
    if Magica[f_nou][c_nou] == 0:
      f = f_nou
      c = c_nou
    else:
      f = (0 if f == n-1 else f+1)




# RELLENA CUADRADO MÁGICO PAR DIVISIBLE POR 4 (¡ERROR! : sólo me funciona para n=4)

if (n % 4) == 0:
  aux = 1
  for f in range(0, n):
    for c in range(0, n):
      if ((f*4)/n == (c*4)/n) or ((f*4)/n + (c*4)/n == 3):
        Magica[f][c] = aux
      else:
        Magica[n-1-f][n-1-c] = aux
      aux = aux + 1



# RELLENA CUADRADO MÁGICO PAR NO DIVISIBLE POR 4 (¡POR HACER!)
# ...



# IMPRIME LA MATRIZ , CON SUMAS

print('Cuadrado mágico', n, 'x', n)
print('Cada fila, columna y diagonal debe sumar', (n*n*n + n)/2, '\n')

# Imprime las filas y su suma
for f in range(0, n):
  suma = 0
  print('|', end='')
  for c in range(0, n):
    print(f'{Magica[f][c]:4}', end='')
    suma = suma + Magica[f][c]
  print(f'| {suma:4}')
  
# Línea de separación
print(' ' + ('----'*n))

# Imprime las columnas y su suma
print(' ', end='')
for c in range(0, n):
  suma = 0
  for f in range(0, n):
    suma = suma + Magica[f][c]
  print(f'{suma:4}', end='')
print()
