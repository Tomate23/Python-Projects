# Pido cuántas asignaturas
num_asign = 0
while num_asign < 1 :
  num_asign = int( input('¿Cuántas asignaturas estudias? ') )

# Pido cuántos meses
num_meses = 0
while num_meses < 1 :
  num_meses = int( input('¿Cuántos meses estudias? ') )

# Pido las diferentes horas de estudio
print()
estudio = []
for f in range(0, num_asign) :
  estudio.append( [] )
  for c in range(0, num_meses) :
    horas = float( input(f'¿Cuántas horas estudias la asignatura [{f}] el mes [{c}]? ') )
    estudio[f].append( horas )



# Calculo el total de horas por asignaturas y el total de horas por meses
# Guardaré dichos totales en sendos vectores

# Relleno con ceros el vector de totales por asignatura
suma_asign = []
for f in range(0, num_asign) :
  suma_asign.append(0.0)

# Relleno con ceros el vector de totales por mes
suma_mes = []
for c in range(0, num_meses) :
  suma_mes.append(0.0)

# Cada celda la sumo al total de asignatura y total de mes correspondientes
for f in range(0, num_asign) :
  for c in range (0, num_meses) :
    suma_asign[f] = suma_asign[f] + estudio[f][c]
    suma_mes[c]   = suma_mes[c]   + estudio[f][c]



# Imprimo las horas de estudio y totales en formato hoja de cálculo
print()

# Imprimo el número de los meses
print('              |', end='')
for c in range(0, num_meses) :
  print(f'  mes {c:2} |', end='')
print('    TOTAL')

# Imprimo una línea horizontal
print('--------------+', end='')
for c in range(0, num_meses) :
  print(f'---------+', end='')
print('---------')

# Imprimo cada fila, con el total de horas por asignatura al final
for f in range(0, num_asign) :
  print(f'asignatura {f:2} |', end='')
  for c in range(0, num_meses) :
    print(f'{estudio[f][c]:8.2f} |', end='')
  print(f' {suma_asign[f]:8.2f}')

# Imprimo una línea horizontal
print('--------------+', end='')
for c in range(0, num_meses) :
  print(f'---------+', end='')
print('---------')

# Imprimo el total de cada mes
print('TOTAL         |', end='')
for c in range(0, num_meses) :
  print(f'{suma_mes[c]:8.2f} |', end='')
print()

# Imprimo el máximo de los totales por asignatura
max_horas = max(suma_asign)
max_asign = suma_asign.index(max_horas)
print()
print(f'La asignatura más estudiada es {max_asign} con {max_horas} horas')

