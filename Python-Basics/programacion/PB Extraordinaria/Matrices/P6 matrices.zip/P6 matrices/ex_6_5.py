# Pedimos el número de filas de la matriz
num_f = 0
while num_f < 1 :
  num_f = int( input('¿Cuántas filas quieres? ') )

# Pedimos el número de columnas de la matriz
num_c = 0
while num_c < 1 :
  num_c = int( input('¿Cuántas columnas quieres? ') )

# Pedimos los elementos de la matriz
casinula = []
num_elem = 0
for f in range(0, num_f) :
  casinula.append( [] )
  for c in range(0, num_c) :
    casinula[f].append( float( input(f'Dame el elemento [{f}][{c}] de la 1a matriz: ') ) )
    if casinula[f][c] != 0:
      num_elem = num_elem + 1

# Calculamos la matriz compacta
compacta = []
i = 0
for f in range(0, len(casinula)) :
  for c in range(0, len(casinula[f])) :
    if casinula[f][c] != 0 :
      compacta.append([f, c, casinula[f][c]])
      i = i + 1

# Imprimimos la matriz quasinula
print()
print('REPRESENTACIÓN NO COMPACTA: elementos =', num_elem*100.0/(num_f*num_c), '%')
for f in range(0, len(casinula)) :
  print('| ', end='')
  for c in range(0, len(casinula[f])) :
    print(f'{casinula[f][c]:8.2f} ', end='')
  print('|')

# Imprimimos la matriz compacta
print()
print('REPRESENTACIÓN COMPACTA: [fila columna elemento]')
for f in range(0, len(compacta)) :
  print(f'| {compacta[f][0]:2} {compacta[f][1]:2} {compacta[f][2]:8.2f} |')

