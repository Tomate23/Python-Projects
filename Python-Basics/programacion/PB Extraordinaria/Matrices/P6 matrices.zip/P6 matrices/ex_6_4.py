ciudades = [[0, 100, 156,  98, 296, 409],
            [0,   0, 256, 198, 396, 509],
            [0,   0,   0,  91, 140, 319],
            [0,   0,   0,   0, 231, 311],
            [0,   0,   0,   0,   0, 181],
            [0,   0,   0,   0,   0,   0]]

nombres = ['BARCELONA', 'GERONA', 'LERIDA', 'TARRAGONA', 'ZARAGOZA', 'TERUEL']



# Imprimo la lista de ciudades para informar al usuario

print('\nLISTADO DE CIUDADES:')
print(nombres)



# Pido al usuario el nombre de las ciudades

print('\nDISTANCIA ENTRE DOS CIUDADES:')

ciudad1 = ''
while not (ciudad1 in nombres):
  ciudad1 = input('Introduce el nombre de la primera ciudad: ')
  ciudad1 = ciudad1.upper()

ciudad2 = ''
while not (ciudad2 in nombres):
  ciudad2 = input('Introduce el nombre de la segunda ciudad: ')
  ciudad2 = ciudad2.upper()

# Como sólo guardé media matriz, si la distancia que me piden no está en el
# triángulo que contiene las distancias, busco la simétrica intercambiando la fila
# con la columna. Por ejemplo: distancia de ciudad 4 a 1 = distania de ciudad 1 a 4

i = nombres.index( ciudad1 )
j = nombres.index( ciudad2 )
print(f'La distancia entre las ciudades {ciudad1} y {ciudad2} es ', end='')
if i < j:
  print(ciudades[i][j])
else:
  print(ciudades[j][i])



# Para encontrar dónde está el máximo, recorro toda la matriz guardando las
# coordenadas de las casillas cuya distancia es mayor que la del máximo.
# En este caso, recorro sólo el triángulo donde he guardado distancias.

print('\nDISTANCIA MÀXIMA ENTRE CIUDADES')

max_f = 0
max_c = 0
for i in range(0, len(ciudades)-1):
  for j in range(i+1, len(ciudades)):
    if ciudades[i][j] > ciudades[max_f][max_c]:
      max_f = i
      max_c = j
print(f'La distancia máxima es {ciudades[max_f][max_c]} km. , entre las ciudades {nombres[max_f]} y {nombres[max_c]}')



# Recorro la diagonal superior a la principal sumando las distancias.
# Y añado al total la casilla superior derecha ("volver a inicio").

print('\nRECORRIDO CIRCULAR')

total = 0
for i in range(0, len(ciudades)-1):
  total = total + ciudades[i][i+1]
  print(f' {nombres[i]} ->', end='')
total = total + ciudades[0][len(ciudades)-1]
print(f' {nombres[0]}')
print(f'La distancia de un recorido circular entre ciudades es {total} km.')

