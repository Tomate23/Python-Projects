# Pido el número de alumnos y el número de notas por alumno

num_alum = int( input('¿Cuántos alumnos tenemos? ') )
while num_alum < 1:
  num_alum = int( input('¿Cuántos alumnos tenemos? ') )

num_notas = int( input('¿Cuántas notas por alumno quieres? ') )
while num_notas < 1:
  num_notas = int( input('¿Cuántas notas por alumno quieres? ') )



# Declaro la estructura de datos Alumno

class Alumno():
  def __init__(self):
    self.nombre = ''
    self.notas = [0.0] * num_notas
    self.final = 0.0



clase = []

for i in range(0, num_alum):

    # creo una variable de tipo Alumno con espacio para la información
    a = Alumno()

    # Pido los datos del alumno
    print()
    a.nombre = input(f'Introduce el nombre del alumno {i+1} : ')
    for j in range(0, num_notas):
      n = float( input(f'Introduce la nota {j+1} del alumno {i+1} : ') )
      while (n < 0) or (n > 10):
        n = float( input(f'Introduce la nota {j+1} del alumno {i+1} : ') )
      a.notas[j] = n

    clase.append(a)



# Calculo la nota final de los alumnos

print('Informe de notas finales')
print('------------------------')

for i in range(0, len(clase)):

  clase[i].final = 0     # innecesario (ya era el valor inicial)

  if len(clase[i].notas) == 0:
    print(clase[i].nombre, ': sin notas')
  else:
    for j in range(0, len(clase[i].notas)):
      clase[i].final = clase[i].final + float(clase[i].notas[j])
    clase[i].final = clase[i].final / len(clase[i].notas)

  # Escribo el resultado de la nota final de cada alumno
  print(clase[i].nombre , ':' , clase[i].final)

