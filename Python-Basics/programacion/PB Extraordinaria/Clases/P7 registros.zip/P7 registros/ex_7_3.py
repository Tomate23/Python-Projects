# Mediante DICCIONARIO

p1 = {'nombre':'Calico', 'nace':{'dia':22 , 'mes':1 , 'año':1971} , 'telef':666}

p1['nace']['mes'] = 5

print(p1)





# Mediante CLASE con constructor __init__ sin parámetros

class Fecha:
  def __init__(self):
    self.dia = 0
    self.mes = 0
    self.año = 0

class Persona:
  def __init__(self):
    self.nombre = ''
    self.nace = Fecha()
    self.telef = ''

p2 = Persona()
p2.nombre = 'Calico'
p2.nace.dia = 22
p2.nace.mes = 1
p2.nace.año = 1971
p2.telef = 666

p2.nace.mes = 5

print(p2.nombre, ' (', p2.nace.dia, '/', p2.nace.mes, '/', p2.nace.año, ') : ', p2.telef, sep='')





# Mediante CLASE con constructor __init__ con parámetros y método __str__

class Fecha:

  def __init__(self, param1, param2, param3):
    self.dia = param1
    self.mes = param2
    self.año = param3

  def __str__(self):
    return str(self.dia) + '/' + str(self.mes) + '/' + str(self.año)



class Persona:

  def __init__(self, param1, param2, param3):
    self.nombre = param1
    self.nace = param2
    self.telef = param3

  def __str__(self):
    return str(self.nombre) + ' (' + str(self.nace) + ') : ' + str(self.telef)



p3 = Persona('Calico', Fecha(22, 1, 1971), 666)

p3.nace.mes = 5

print(p3)

