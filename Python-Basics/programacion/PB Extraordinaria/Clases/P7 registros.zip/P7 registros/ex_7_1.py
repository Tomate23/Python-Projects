class Punto3D:
  def __init__(self):
    self.x = 0.0
    self.y = 0.0
    self.z = 0.0

# Ejemplo de uso

p = Punto3D()
p.x = 5.2
p.y = 3.4
p.z = 8.0





class Pixel:
  def __init__(self):
    self.R = 0
    self.G = 0
    self.B = 0

# Ejemplo de uso

p = Pixel()
p.R = 125
p.G = 125
p.B = 0





class Imagen:
  def __init__(self):
    self.filas = 0
    self.columnas = 0
    self.pixels = []

# Ejemplo de uso

i = Imagen()
i.filas = 768
i.columnas = 1024
for f in range(0, i.filas):
  i.pixels.append([])
  for c in range(0, i.columnas):
    i.pixels[f].append( Pixel() )
    i.pixels[f][c].R =  50
    i.pixels[f][c].G = 125
    i.pixels[f][c].B = 200





class Complejo:
  def __init__(self):
    self.real = 0.0
    self.imag = 0.0

# Ejemplo de uso

c = Complejo()
c.real = -1.0
c.imag = -2.0





class Fecha:
  def __init__(self):
    self.dia = 0
    self.mes = 0
    self.año = 0

# Ejemplo de uso

f = Fecha()
f.dia = 22
f.mes = 1
f.año = 1971





class Persona:
  def __init__(self):
    self.nombre = ''
    self.nace = Fecha()
    self.telef = ''

# Ejemplo de uso

p2 = Persona()
p2.nombre = 'Calico'
p2.nace.dia = 22
p2.nace.mes = 1
p2.nace.año = 1971
p2.telef = 666





class Agenda:
  def __init__(self):
    self.listado = []

# Ejemplo de uso (aprovechando el ejemplo anterior)

a = Agenda()
a.listado.append( p2 )




'''
El principal avantatge de treballar amb variables estructurades homogènies és poder processar tots els seus elements de la mateixa manera mitjançant iteracions i accés indexat. Quan no hem de fer servir aquesta característica, l’ús de variables estructurades heterogènies dóna més llegibilitat al programa. A l’exemple del punt de l’espai (sigui a una variable d’aquest tipus), per referenciar els valors de les seves coordenades és més elegant escriure a.x, a.y i a.z que a[0], a[1] i a[2], però si es tractés d’un punt d’un espai n-dimensional, on n és molt gran o introduït per l’usuari, i haguéssim de processar automàticament les coordenades, ens seria més útil accés indexat a[i].
'''

