class Punto3D:
  def __init__(self, x, y, z):
    self.x = x
    self.y = y
    self.z = z

  def __str__(self):
    return '(' + str(self.x) + ' , '  + str(self.y) + ' , '  + str(self.z) + ')'

# Ejemplo de uso

p = Punto3D(5.2 , 3.4 , 8.0)
print(p)





class Pixel:
  def __init__(self, R, G, B):
    self.R = (R if 0 <= R <= 255 else 0)
    self.G = (G if 0 <= G <= 255 else 0)
    self.B = (B if 0 <= B <= 255 else 0)

  def __str__(self):
    return 'R:' + hex(self.R) + ' G:'+hex(self.G) + ' B:'+hex(self.B)

# Ejemplo de uso

p = Pixel(125, 125, 0)
print(p)





class Imagen:
  def __init__(self, columnas, filas):
    self.filas = filas
    self.columnas = columnas
    self.pixels = []
    for f in range(0, self.filas):
      self.pixels.append([])
      for c in range(0, self.columnas):
        self.pixels[f].append( Pixel(0,0,0) )

# Ejemplo de uso

i = Imagen(1024, 768)





class Complejo:
  def __init__(self, real, imag):
    self.real = real
    self.imag = imag

  def __str__(self):
    return str(self.real) + ('+' if self.imag > 0 else '-') + str(abs(self.imag)) + 'i'

# Ejemplo de uso

c = Complejo(-1, -2)
print(c)





class Fecha:
  def __init__(self, dia, mes, año):
    self.dia = (dia if 1 <= dia <= 31 else 1)
    self.mes = (mes if 1 <= mes <= 12 else 1)
    self.año = año

  def __str__(self):
    return str(self.dia) + '/' + str(self.mes) + '/' + str(self.año)

# Ejemplo de uso

f = Fecha(22, 1, 1971)
print(f)





class Persona:
  def __init__(self, nombre, nace, telef):
    self.nombre = nombre
    self.nace = nace
    self.telef = telef

  def __str__(self):
    return self.nombre + ' (' + str(self.nace) + ') : ' + str(self.telef)

# Ejemplo de uso

p2 = Persona('Calico', Fecha(22, 1, 1971), 666)
print(p2)





class Agenda:
  def __init__(self):
    self.listado = []

  def __str__(self):
    for p in self.listado:
      return str(p) + '\n'


# Ejemplo de uso (aprovechando el ejemplo anterior)

a = Agenda()
a.listado.append( p2 )
print(a)




'''
El principal avantatge de treballar amb variables estructurades homogènies és poder processar tots els seus elements de la mateixa manera mitjançant iteracions i accés indexat. Quan no hem de fer servir aquesta característica, l’ús de variables estructurades heterogènies dóna més llegibilitat al programa. A l’exemple del punt de l’espai (sigui a una variable d’aquest tipus), per referenciar els valors de les seves coordenades és més elegant escriure a.x, a.y i a.z que a[0], a[1] i a[2], però si es tractés d’un punt d’un espai n-dimensional, on n és molt gran o introduït per l’usuari, i haguéssim de processar automàticament les coordenades, ens seria més útil accés indexat a[i].
'''

