# Creamos un nuevo tipo de datos, clase Producto.
# Una variable (objeto) de dicha clase almacenará nombre, precio y cantidad

class Producto:
  def __init__(self):
    self.nombre = ''
    self.precio = 0.0
    self.cantidad = 0.0



# Lista de la compra que contendrá los diferentes productos

compra = []



while True:

  print('1. Añadir productos a la lista de la compra')
  print('2. Sacar productos de la lista de la compra')
  print('3. Modificar productos de la lista de la compra')
  print('4. Listar los productos a comprar')
  print('0. Salir')
  print('---------------------------------------------')

  opcion = input('¿Qué opción quieres? ')
  print('\n\n\n\n\n')

  if opcion == '1':

    # Creamos una nueva variable de tipo Producto, pedimos sus datos,
    # y lo añadimos a la lista (comprobando si ya existía)
    print('AÑADIR PRODUCTOS\n')
    p = Producto()
    p.nombre = input('¿Qué nombre de producto? ')

    # Comprueba que el producto no estuviera ya en la llista
    encontrado = False
    for i in range(0, len(compra)):
      if p.nombre == compra[i].nombre:
        encontrado = True
        break

    if encontrado:
      print('El producto ya existía')
      print(compra[i].nombre, compra[i].cantidad, 'x', compra[i].precio, 'euros')
    else:
      p.precio = float( input('¿Qué precio tiene? ') )
      p.cantidad = float( input('¿Qué cantidad a comprar? ') )
      compra.append( p )

  elif opcion == '2':

    # Borrar un producto. Pedimos su nombre y lo buscamos   
    print('BORRAR PRODUCTOS\n')
    nombre = input('¿Qué nombre de producto a borrar? ')

    # Comprueba que el producto estuviera en la llista
    encontrado = False
    for i in range(0, len(compra)):
      if nombre == compra[i].nombre:
        encontrado = True
        break

    if encontrado:
      print(compra[i].nombre, compra[i].cantidad, 'x', compra[i].precio, 'euros')
      compra.pop( i )
    else:
      print('El producto no existía')


  elif opcion == '3':

    # Modificar un producto. Pedimos su nombre y lo buscamos
    print('MODIFICAR PRODUCTOS\n')
    nombre = input('¿Qué nombre de producto a modificar? ')

    # Comprueba que el producto estuviera en la llista
    encontrado = False
    for i in range(0, len(compra)):
      if nombre == compra[i].nombre:
        encontrado = True
        break

    if encontrado:
      print(compra[i].nombre, compra[i].cantidad, 'x', compra[i].precio, 'euros')
      compra[i].precio = float( input('¿Qué nuevo precio tiene? ') )
      compra[i].cantidad = float( input('¿Qué nueva cantidad a comprar? ') )
    else:
      print('El producto no existía')

  elif opcion == '4':

    # Listar productos, mostrando el total a pagar
    print('LISTAR PRODUCTOS\n')
    total = 0
    for p in compra:
      print(f'{p.nombre:20}   {p.cantidad:2.1f} unidades   {p.precio:3.2f} euros')
      total = total + p.cantidad*p.precio
    print('------------------------------------------------')
    print(f'TOTAL                                {total:5.2f} euros')

  elif opcion == '0':

    # Salir del programa
    print('¡Adios!')
    break

  else:

    # Opción incorrecta
    print('Opción incorrecta')
     
  print('\n\n\n\n\n')
  opcion = input('Pulsa <ENTER> para continuar ...')
