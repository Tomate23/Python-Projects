# Guardaremos los productos en un diccionario, donde la clave es su nombre.
# El valor asociado a la clave es un pequeño diccionario con precio y cantidad.

# Lista de la compra que contendrá los diferentes productos

compra = {}



while True:

  print('1. Añadir productos a la lista de la compra')
  print('2. Sacar productos de la lista de la compra')
  print('3. Modificar productos de la lista de la compra')
  print('4. Listar los productos a comprar')
  print('0. Salir')
  print('---------------------------------------------')

  opcion = input('¿Qué opción quieres? ')
  print('\n\n\n\n\n')

  if opcion == '1':

    # Pedimos sus datos,del producto y lo añadimos a la lista, comprobando si existía
    print('AÑADIR PRODUCTOS\n')
    nombre = input('¿Qué nombre de producto? ')

    # Comprueba que el producto no estuviera ya en la llista
    if nombre in compra:
      print('El producto ya existía')
      print(nombre, compra[nombre].cantidad, 'x', compra[nombre].precio, 'euros')
    else:
      precio = float( input('¿Qué precio tiene? ') )
      cantidad = float( input('¿Qué cantidad a comprar? ') )
      compra[nombre] = {'precio':precio, 'cantidad':cantidad}

  elif opcion == '2':

    # Borrar un producto. Pedimos su nombre y lo buscamos   
    print('BORRAR PRODUCTOS\n')
    nombre = input('¿Qué nombre de producto a borrar? ')

    # Comprueba que el producto estuviera en la llista
    if nombre in compra:
      print(nombre, compra[nombre]['cantidad'], 'x', compra[nombre]['precio'], 'euros')
      compra.pop( nombre )
    else:
      print('El producto no existía')


  elif opcion == '3':

    # Modificar un producto. Pedimos su nombre y lo buscamos
    print('MODIFICAR PRODUCTOS\n')
    nombre = input('¿Qué nombre de producto a modificar? ')

    # Comprueba que el producto estuviera en la llista
    if nombre in compra:
      print(nombre, compra[nombre]['cantidad'], 'x', compra[nombre]['precio'], 'euros')
      compra[nombre]['precio'] = float( input('¿Qué nuevo precio tiene? ') )
      compra[nombre]['cantidad'] = float( input('¿Qué nueva cantidad a comprar? ') )
    else:
      print('El producto no existía')

  elif opcion == '4':

    # Listar productos, mostrando el total a pagar
    print('LISTAR PRODUCTOS\n')
    total = 0
    for nombre in compra:
      print(f"{nombre:20}   {compra[nombre]['cantidad']:2.1f} unidades   {compra[nombre]['precio']:3.2f} euros")
      total = total + compra[nombre]['cantidad']*compra[nombre]['precio']
    print('------------------------------------------------')
    print(f'TOTAL                                {total:5.2f} euros')

  elif opcion == '0':

    # Salir del programa
    print('¡Adios!')
    break

  else:

    # Opción incorrecta
    print('Opción incorrecta')
     
  print('\n\n\n\n\n')
  opcion = input('Pulsa <ENTER> para continuar ...')

