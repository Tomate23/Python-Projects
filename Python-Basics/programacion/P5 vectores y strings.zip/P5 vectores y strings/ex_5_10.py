frase = input('Introduce una frase: ')

palabras = 0

# Cuento una palabra cada vez que paso de un
# caracter no alfabético a un caracter alfabético

c_ant = ''
for c in frase:
  if c.isalpha() and not(c_ant.isalpha()):
    palabras = palabras + 1
  c_ant = c

print('La frase tiene', palabras, 'palabras')

