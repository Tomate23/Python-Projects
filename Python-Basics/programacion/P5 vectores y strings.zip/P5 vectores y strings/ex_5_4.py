MAX_GRUPO = 30

# Pedimos cuantos alumnos tiene el grupo

num = int( input('¿Cuántos alumnos tiene el grupo? ') )
while num < 1 or num > MAX_GRUPO:
  print('Valor incorrecto. Debe estar entre 1 y', MAX_GRUPO)
  num = int( input('¿Cuántos alumnos tiene el grupo? ') )

# Leemos las notas de todos los alumnos

notas = []

for i in range(num):
  x = int( input(f'¿Qué valor para la nota del alumno {i+1}? ') )
  while x < 0 or x > 10:
    print('Valor incorrecto. Debe estar entre 0 y 10.')
    x = int( input(f'¿Qué valor para la nota del alumno {i+1}? ') )
  notas.append( x )

# Contamos el número de suspensos, aprobados, notables y excelentes

sus = 0
apr = 0
ntb = 0
exl = 0

for e in notas:
  if e < 5:
    sus = sus + 1
  elif e < 7:
    apr = apr + 1
  elif e < 9:
    ntb = ntb + 1
  else:
    exl = exl + 1

print(f'Hay {sus} suspensos, {apr} aprobados, {ntb} notables y {exl} excelentes')

