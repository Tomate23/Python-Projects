import random

MAX_NUM = 15

# Rellenamos el vector con números aleatorios.

vector = []

for i in range(MAX_NUM):
  vector.append( random.randint(1, 100) )

# Separamos pares e impares

pares = []
impares = []

for e in vector:
  if e % 2 == 0:
    pares.append( e )
  else:
    impares.append( e )

# Imprimimos resultados
  
print('VECTOR:', vector)
print('PARES:', pares)
print('IMPARES:', impares)

