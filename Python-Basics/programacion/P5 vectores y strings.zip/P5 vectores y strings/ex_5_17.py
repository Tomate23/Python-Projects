conjuros = list(map(int, input('¿Qué daño hace cada conjuro que lanzas (separa con espacios)? ').split(' ')))
daño_esperado = sum(conjuros)
print('Tu ataque intenta disminuir la energía del contrincante en', daño_esperado, 'puntos')
daño_real = int( input('¿Qué daño real han hecho los conjuros? ') )

diferencia = daño_esperado - daño_real

combinaciones = []

for i in range(0, len(conjuros)-1):
  for j in range(i+1, len(conjuros)):
    if conjuros[i] + conjuros[j] == diferencia:
      combinaciones.append((conjuros[i] , conjuros[j]))

print('Las posibles combinaciones de conjuros que han fallado son:', combinaciones)
