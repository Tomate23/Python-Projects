import re



print('a) Palabras que tienen una o más b o una o más d seguidas de una n')
s = input('Introduce una cadena: ')
print( re.search('(b+|d+)n' , s) )



print('b) Palabras que tienen dos o más a seguidas')
s = input('Introduce una cadena: ')
print( re.search('a(a+)' , s) )



print('c) Palabras cuya tercera letra es b')
s = input('Introduce una cadena: ')
print( re.search('^..b' , s) )



print('d) Palabras que contienen pan o plan')
s = input('Introduce una cadena: ')
print( re.search('p(l?)an' , s) )



print('e) Palabras que acaban en cial')
s = input('Introduce una cadena: ')
print( re.search('cial$' , s) )



print('f) Una línea vacía')
s = input('Introduce una cadena: ')
print( re.search('^$' , s) )



print('g) Palabras que contienen una cifra del 0 al 5')
s = input('Introduce una cadena: ')
print( re.search('[0-5]' , s) )



print('h) Palabras que acaban en o, más una letra que no sea n')
s = input('Introduce una cadena: ')
print( re.search('o[^n]$' , s) )



print('i) Contraseñas que contienen seis letras seguidas de dos números')
s = input('Introduce una cadena: ')
print( re.search('[a-zA-Z]{6}[0-9]{2}' , s) )



print('j) El nombre de un fichero con extensión .txt , .odt o .pdf')
s = input('Introduce una cadena: ')
print( re.search('.+\.(txt|odt|pdf)$' , s) )



print('k) Una fecha con el formato dd/mm/aaaa')
s = input('Introduce una cadena: ')
print( re.search('^[0-9]{2}\/[0-9]{2}\/[0-9]{4}$' , s) )



print('l) Una dirección de correo electrónico con el formato nombre@dominio.xxx')
s = input('Introduce una cadena: ')
print( re.search('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$' , s) )
