a = [0, 0]                        #    a->|0|0|
b = [0, 0, 0]                     #    b->|0|0|0|

a[0] = 2                          #    a->|2|0|      b->|0|0|0|
a[1] = a[0] ** a[0]               #    a->|2|4|      b->|0|0|0|
a.append( a[0] + a[1] )           #    a->|2|4|6|    b->|0|0|0|

b[1 + 1] = a[0] - 1               #    a->|2|4|6|    b->|0|0|1|
b[a[0]-1] = 2*a[1] - 1            #    a->|2|4|6|    b->|0|7|1|
b[2.0*a[0]-a[1]] = b[0] + 1       #    ERROR semántico   indice no entero

for i in range(0,3):
  b[i] = b[i] + i                 #    a->|2|4|6|    b->|0|8|3|    i|2|

b[i+1] = 9                        #    ERROR ejecución   índice fuera de rango

b = a                             #    a->|2|4|6|<-b
a[2] = 8                          #    a->|2|4|8|<-b
print(b)                          #    Al modificar a modifico b, y viceversa
