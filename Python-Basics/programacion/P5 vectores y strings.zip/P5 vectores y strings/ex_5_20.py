import sys
 
print(len(sys.argv), 'argumentos:')

for arg in sys.argv:
  print('  ', arg)



'''
Este programa imprime los argumentos recibidos por la línea de
comandos. El primer argumento es el nombre del programa.

Los argumentos se reciben en una lista de cadenas de caracteres
llamada sys.argv[].

Para más potencia a la hora de procesar argumentos, prueba argparse:

  https://docs.python.org/3/howto/argparse.html
'''

