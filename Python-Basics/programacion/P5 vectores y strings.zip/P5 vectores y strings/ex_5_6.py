# Vector que tiene en cada posición, de la 0 a la 9,
# la palabra correspondiente al número de la posición

p = ['cero', 'uno', 'dos', 'tres', 'cuatro', 'cinco', 'seis', 'siete', 'ocho', 'nueve']



# Primera manera: tenemos el número en un string y lo recorremos carácter a carácter 

n = input('dame número: ')
s = ''

for e in n:
  s = s + p[ int(e) ] + ' '
		
print(s)



# Segunda manera: tenemos el número en un entero.
# Obtenemos su dígito más pequeños tomando el resto de dividir: % 10 .
# Eliminamos su dígito más pequeños tomando el cociente de dividir // 10 .

n = int( input('dame número: ') )
s = ''

while True:
  c = n % 10
  s = p[ c ] + ' ' + s
  n = n // 10
  if n == 0:
    break
		
print(s)

