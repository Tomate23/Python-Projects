import random


PALOS = '♠ ♡ ♢ ♣'.split(' ')

RANGO = '2 3 4 5 6 7 8 9 10 J Q K A'.split(' ')

JUGADORES = 'Ana Bob Edu Jon'.split(' ')


# Crea un nuevo mazo de 52 cartas

mazo = [(p, r) for r in RANGO for p in PALOS]


# Baraja el mazo

random.shuffle(mazo)


# Reparte las cartas

reparte = (mazo[0::4], mazo[1::4], mazo[2::4], mazo[3::4])


# Asocia cada una de las cuatro manos repartidas a un jugador

manos = {n: h for n, h in zip(JUGADORES, reparte)}


# Imprime las manos de los jugadores

for nombre, cartas in manos.items():

    print(f'{nombre}: {" ".join(f"{p+r:<3}" for (p, r) in cartas)}')

print('-'*60)


# Escoge qué jugador comienza

primer_jugador = random.choice(JUGADORES)

primer_indice = JUGADORES.index( primer_jugador )

turnos = JUGADORES[primer_indice:] + JUGADORES[:primer_indice]


# Juega cartas aleatorias de las manos de los jugadores hasta que la mano se vacía

while manos[primer_jugador]:

    for nombre in turnos:

        carta = random.choice(manos[nombre])

        manos[nombre].remove(carta)

        print(f'{nombre}: {carta[0] + carta[1]:<3}  ', end='')

    print()
