cameo = input('Cameo a buscar: ')
texto = input('Texto donde buscar: ')

apariciones = 0
subrayado = ''

# Vamos a recorrer el texto donde buscar.
# Cada vez que aparece un carácter del cameo, avanzo el índice del cameo.
# Cuando llego al final del cameo, incremento las apariciones, y vuelvo 
# a la primera letra del cameo. 

i = 0
for c in texto:
  if c.upper() == cameo[i].upper():
    subrayado = subrayado + '^'
    i = i + 1
    if i == len(cameo):
      apariciones = apariciones + 1
      i = 0
  else:
    subrayado = subrayado + ' '

print(texto, ':', apariciones)
print(subrayado)
