import random

NUM_ELEM = 15



# Rellenamos el vector con números aleatorios.

vector = [random.randint(1, 100) for e in range(NUM_ELEM)]

print('Vector sin ordenar: ', vector)



# Hay muchas maneras de ordenar un vector. 
# Utilizaremos el método de ordenación directa porque es muy intuitivo:

# Para cada elemento del vector excepto el último:

for i in range(0, len(vector)-1):

  # Busca la posición del elemento más pequeño de los elementos que quedan por ordenar

  pos_min = i;
  for j in range(i+1, len(vector)):	
    if vector[j] < vector[pos_min]:
      pos_min = j
    
  # Intercambia el elemento a ordenar (en la posición i) con el elemento más pequeño encontrado (en pos_min)

  aux = vector[i]
  vector[i] = vector[pos_min]
  vector[pos_min] = aux



print('Vector ordenado: ', vector)

