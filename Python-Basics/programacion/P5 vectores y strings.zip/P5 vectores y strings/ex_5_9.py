print('Fusión de dos vectores ordenados')
print('--------------------------------\n')

# Pedimos el primer vector

cadena = input('Introduce los elementos del primer vector separados por un espacio: ')
vector1 = [int(i) for i in cadena.split(' ')]

# Pedimos el segundo vector

cadena = input('Introduce los elementos del segundo vector separados por un espacio: ')
vector2 = [int(i) for i in cadena.split(' ')]


# vectorR = sorted(vector1 + vector2) seria más corto, pero ineficiente

# Utilizaremos dos índices para fusionar el vector:
# - Un índice para indicar donde va del primer vector
# - Un índice para indicar donde va del segundo vector

vectorR = []
pos1 = pos2 = 0

while True:
  if vector1[pos1] <= vector2[pos2]:
       vectorR.append(vector1[pos1])
       pos1 = pos1 + 1
       if pos1 == len(vector1):
         vectorR = vectorR + vector2[pos2:]
         break
  else:
       vectorR.append(vector2[pos2])
       pos2 = pos2 + 1
       if pos2 == len(vector2):
         vectorR = vectorR + vector1[pos1:]
         break



# Imprimimos el vector fusionado

print('Vector fusionado: ', vectorR)
