texto = input('Introduce un texto: ')

tabla = {}
for c in texto:
  if c in tabla:
    tabla[c] += 1
  else:
    tabla[c] = 1

print('Frecuencia de aparicion de caracteres')

for clave in tabla:
  print(clave ,'->', tabla[clave])
