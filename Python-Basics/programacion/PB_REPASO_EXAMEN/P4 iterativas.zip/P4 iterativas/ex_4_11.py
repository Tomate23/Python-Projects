n = int( input('Dame un número entero mayor que cero : ') )
while n <= 0:
  n = int( input('Dame un número entero mayor que cero : ') )

j = 1
incr = 1
while j > 0:
  
  # imprimimos una línea de asteriscos de longitud j
  for i in range(1, j+1):
    print('*', end='')
  print()

  # Si ya hicimos la parte creciente del triángulo, pasamos a la decreciente
  if j == n:
    incr = -1

  # Calculamos la longitud del siguiente lado
  j = j + incr



# Lo podemos hacer con un solo for aprovechando la repetición de cadenas

for j in range(1, n+1):
    print('*' * j)

for j in range(n-1, 0, -1):
    print('*' * j)
