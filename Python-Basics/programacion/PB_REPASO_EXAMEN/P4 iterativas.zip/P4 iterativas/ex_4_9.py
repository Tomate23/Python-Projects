import math

x = float( input('Dame un ángulo entre -180º y 180º y calcularé su seno : ') )
while not(-180 <= x <= 180):
  x = float( input('Dame un ángulo entre -180º y 180º y calcularé su seno : ') )

# Pasamos los grados a radianes

x = x * math.pi / 180;

error = float( input('Introduce el error máximo permitido : ') )
while error <= 0:
  error = float( input('Introduce el error máximo permitido : ') )

i = 1
termino = x
sinus = x

# Calculamos el sinus hasta que el error sea suficientemente pequeño

while math.fabs(termino) > error:
  i = i + 2
  termino = - termino * x*x/(i*(i-1))
  sinus = sinus + termino

print(f'El sinus de {x} radianes es {sinus}')
