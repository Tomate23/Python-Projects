# Pedimos el número del que queremos calcular el sumatorio

n = int( input('Introduce un valor : ') )
while n < 0:
  n = int( input('Introduce un valor : ') )

# La estructura repetitiva for... es la más adecuada para el problema
# ya que conocemos el el número de veces (n) a ejecutar la iteración

total = 0;
for i in range(1, n+1):
  print(f'El término {i} es {1/(i**2)}')
  total = total + 1.0/(i*i)
  
print('La suma de los términos es', total)




# Con while sería ...

total = 0
i = 1
while i <= n:
  print(f'El término {i} es {1/(i**2)}')
  total = total + 1.0/(i*i)
  i = i + 1

print('La suma de los términos es', total)
