n = int( input('Dame un número de latas a apilar : ') )
while n < 1:
  n = int( input('Dame un número de latas a apilar : ') )

# Comenzamos a apilar. Restaremos cantidades sucesivas de latas
# a las latas que tenemos: primero una, después dos,
# y así sucesivamente hasta que no quede ninguna. 

i = 1
while i <= n:
  n = n - i
  i = i + 1

# Si al final han quedado cero latas justas, era apilable

if n > 0:
  print(f'No apilables: puedo hacer {i-1} filas y me sobran {n} latas')
else:
  print(f'Se pueden apilar en {i-1} filas')





# Existe una fórmula que da el número de filas
# a partir del número de latas:
#
#    ( math.sqrt(1 + 8*n) - 1 ) / 2
