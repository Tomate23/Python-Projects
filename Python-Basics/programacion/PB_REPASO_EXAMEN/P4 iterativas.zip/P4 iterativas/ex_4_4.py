print('Cálculo de la media de una serie de puntos (0 0 para acabar)')
print('------------------------------------------------------------')

# Inicializamos las variables

suma_x = 0
suma_y = 0
num = 0

# Leemos datos y los procesamos hasta que introducen 0 0

x = float( input('Introduce la coordenada x del punto : ') )
y = float( input('Introduce la coordenada y del punto : ') )
while (x != 0) or (y != 0):
  suma_x = suma_x + x
  suma_y = suma_y + y
  num = num + 1
  x = float( input('Introduce la coordenada x del punto : ') )
  y = float( input('Introduce la coordenada y del punto : ') )

# Damos los resultados

if num != 0:
  print(f'La media de los puntos es ({(suma_x/num):8.2f},{(suma_y/num):8.2f})')
else:
  print('No has introducido ningún punto')
