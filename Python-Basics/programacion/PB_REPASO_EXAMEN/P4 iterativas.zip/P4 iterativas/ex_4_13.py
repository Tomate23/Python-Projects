# Pedimos un valor sin comprobar límites correctos

while True:
  try:
    x = int(input('Mete un entero: '))
    break
  except ValueError:
    print('Fallaste. Vuelve a probar')



# Pedimos un valor, nota entre 0 y 10, comprobando además límites correctos

while True:
  try:
    x = float(input('Mete una nota entre 0 y 10: '))
    if x >= 0 and x <= 10:
      break
    print('Valor incorrecto')
  except ValueError:
    print('No es un número')
  print('Vuelve a probar')
