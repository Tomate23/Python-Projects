a = int( input('Dame el primer número a multiplicar : ') )
b = int( input('Dame el segundo número a multiplicar : ') )

'''
Podemos optimizar el código añadimos las siguientes líneas que
intercambian los valores de a i b si a < b. De esta manera
sumaremos a veces b, en lugar de b veces a.

  if (a < b) {
    aux = a;
    a = b;
    b = aux;
'''

# Si b es negativa intercambio los signos, que no alterará el resultado

if b < 0:
  b = -b
  a = -a

# Ahora vamos a sumar b veces a

mult = 0
while b > 0:
  mult = mult + a
  b = b - 1

print('El resultado es', mult)



'''
Otra manera de tener en cuenta que "b" podía ser negativo:

  mult = 0

  while b > 0:
    mult = mult + a
    b = b - 1

  while b < 0:
    mult = mult - a
    b = b + 1
'''



'''
Otra manera de tener en cuenta que "b" podía ser negativo:

  mult = 0
  i = 1

  while i <= abs(b):
    mult = mult + a
    i++

  if b < 0:
    mult = -mult
'''
