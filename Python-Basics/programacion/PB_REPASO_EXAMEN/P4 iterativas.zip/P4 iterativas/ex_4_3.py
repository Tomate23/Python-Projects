# Pedimos el número del que queremos calcular el factorial,
# hasta que sea más grande que 0

n = int( input('Introduce un valor : ') )
while n < 0:
  n = int( input('Introduce un valor : ') )

# Calculo el factorial

total = 1
for i in range(1, n+1):
  total = total * i

print(f'El factorial de {n} es {total}')





# También hubiera podido calcularlo ahorrando dos iteraciones
# (cuidado con factorial de 0)

total = n;
for i in range(2, n):
  total = total * i

print(f'El factorial de {n} es {total}')
