import random

n = random.randint(0, 100)

while True:

  x = int( input('Dame un número entre 0 y 100 : ') )

  if x > n:
    print('Era demasiado grande. Prueba un número más pequeño')
  elif x < n:
    print('Era demasiado pequeño. Prueba un número más grande')
  else:
    break

print('¡¡¡Acertaste!!!')
