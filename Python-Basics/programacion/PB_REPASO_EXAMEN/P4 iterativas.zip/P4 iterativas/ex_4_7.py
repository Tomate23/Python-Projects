n = int( input('Dame un número entero no negativo : ') )
while n < 0:
  n = int( input('Dame un número entero no negativo : ') )

if n == 0:
  fib = 0
elif n == 1:
  fib = 1
else:
  ant2 = 0;     # Fibonacci(0) = 0
  ant1 = 1;     # Fibonacci(1) = 1
  for i in range(2, n+1):
    fib = ant1 + ant2
    ant2 = ant1
    ant1 = fib

print(f'El Fibonacci de {n} es {fib}')

# n    = 0  1  2  3  4  5  6  7  8  9 ...
# fibo = 0  1  1  2  3  5  8 13 21 34 ...
