import math

x = float( input('Dame un número positivo y calcularé su raiz cuadrada : ') )
while x < 0:
  print('Incorrecto. Debe ser positivo.')
  x = float( input('Dame un número positivo y calcularé su raiz cuadrada : ') )

error = float( input('Introduce el error máximo permitido entre términos consecutivos : ') )
while error <= 0:
  print('Incorrecto. Debe ser positivo.')
  error = float( input('Introduce el error máximo permitido entre términos consecutivos : ') )

# Calculamos la raiz hasta que el error sea suficientemente pequeño

ant = x
sig = (ant + 1)/2

while (math.fabs(sig - ant) > error):
  ant = sig
  sig = (ant + x/ant)/2

print(f'La raiz cuadrada de {x} es {sig}')
