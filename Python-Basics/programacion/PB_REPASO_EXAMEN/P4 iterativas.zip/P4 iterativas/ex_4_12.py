# Probamos al cuadrado. Para otros valores:
#   for n in range(3, ...): 

n = 2

# Probamos las combinaciones de valores de a y b.
# En realidad podríamos hacer b >= a
# para no repetir combinaciones 

for a in range(1, 101):
  for b in range(1, 101):
    aux = (a**n + b**n) ** (1/n)
    c = int(aux)
    if (aux - c) == 0:
      print(f'{a:3}^{n} + {b:3}^{n} = {c:3}^{n}')
