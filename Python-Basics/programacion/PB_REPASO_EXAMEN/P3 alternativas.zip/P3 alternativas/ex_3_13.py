from math import sqrt

print('Solucionador de ecuaciones de segundo grado: a x² + b x + c = 0')
print('---------------------------------------------------------------')

try:

  a = float( input('Introduce el coeficiente de segundo grado: a = ') )
  b = float( input('Introduce el coeficiente de primer grado: b = ') )
  c = float( input('Introduce el término independiente: c = ') )
  discr = b*b - 4*a*c;
  x1 = (-b + sqrt(discr))/(2*a)
  x2 = (-b - sqrt(discr))/(2*a)
  print('Dos soluciones reales: x =', x1, 'y x =', x2)

except ZeroDivisionError:

  if b != 0:
    print('Ecuación de primer grado con solución x =', -c/b)
  elif c != 0:
    print('Ecuación de primer grado si solución')
  else:
    print('Ecuación de primer grado con infinitas soluciones')

except ValueError:

  x1 = complex( -b/(2*a) , +sqrt(-discr)/(2*a) )
  x2 = complex( -b/(2*a) , -sqrt(-discr)/(2*a) )
  print('Dos soluciones imaginarias: x =', x1, 'y x =', x2)

except:

  print('Error desconocido')

finally:

  print('Gracias por utilizar mi programa')
