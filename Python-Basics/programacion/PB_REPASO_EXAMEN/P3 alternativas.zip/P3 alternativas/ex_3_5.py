a = float( input('Introduce el primer valor: ') )
min = a
max = a

b = float( input('Introduce el segundo valor: ') )
if b < min:
  min = b
else:
  max = b

c = float( input('Introduce el tercer valor: ') )
if c < min:
  min = c
elif c > max:
  max = c

print('El mínimo es', min)
print('El máximo es', max)
