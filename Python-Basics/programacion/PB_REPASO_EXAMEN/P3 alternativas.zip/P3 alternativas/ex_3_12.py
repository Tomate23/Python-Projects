from math import sqrt

print('Solucionador de ecuaciones de segundo grado: a x² + b x + c = 0')

# Pedimos los coeficientes de la ecuación
a = float( input('Introduce el coeficiente de segundo grado: a = ') )
b = float( input('Introduce el coeficiente de primer grado: b = ') )
c = float( input('Introduce el término independiente: c = ') )

if a == 0:
  print('La ecuación no es de segundo grado')
else:
  # auxiliar para el discriminante b² - 4ac
  discr = b*b - 4*a*c;
  if discr == 0:
    print('Solución única x =', -b/(2*a))
  elif discr > 0:
    x1 = (-b + sqrt(discr))/(2*a)
    x2 = (-b - sqrt(discr))/(2*a)
    print('Dos soluciones reales: x =', x1, 'y x =', x2)
  else:
    x1 = complex( -b/(2*a) , +sqrt(-discr)/(2*a) )
    x2 = complex( -b/(2*a) , -sqrt(-discr)/(2*a) )
    print('Dos soluciones imaginarias: x =', x1, 'y x =', x2)
