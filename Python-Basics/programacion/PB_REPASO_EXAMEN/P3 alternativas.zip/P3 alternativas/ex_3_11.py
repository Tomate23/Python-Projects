print('Revisor de fechas')
print('-----------------')

dia = int ( input('Introduce el día: ') )
mes = int ( input('Introduce el mes: ') )
año = int ( input('Introduce el año: ') )

if mes in [1, 3, 5, 7, 8, 10, 12]:
  if 1 <= dia <= 31:
    print('Fecha correcta')
  else:
    print('Día incorrecto')

elif mes in [4, 6, 9, 11]:
  if 1 <= dia <= 30:
    print('Fecha correcta')
  else:
    print('Día incorrecto')

elif mes == 2:
  if 1 <= dia <= (29 if ((año % 4) == 0) else 28):
    print('Fecha correcta')
  else:
    print('Día incorrecto')

else:
  print('Mes incorrecto')
