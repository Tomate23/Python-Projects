a,b,c =  map( int , input('Dame tres valores enteros: ').split(' ') )

# Calcula el mínimo de los tres valores utilizando 
# operadores ternarios ( valor1 if cond else valor2 ) anidados

r = (a if a < c else c) if a < b else (b if b < c else c)

print('Resultado:', r)
