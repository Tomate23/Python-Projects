print('Solucionador de ecuaciones de primer grado: a x + b = 0')

a = float( input('Introduce el coeficiente de primer grado: a = ') )

b = float( input('Introduce el término independiente: b = ') )

if a != 0:
  print('La solución de la ecuación es x =', -b/a)
elif b != 0:
  print('La ecuación no tiene ninguna solución')
else:
  print('La ecuación tiene infinitas soluciones')

