n = float ( input('Introduce un número cualquiera: ') )

if n < 0:
  print(n, 'es negativo')
elif n > 0:
  print(n, 'es positivo')
else:
  print(n, 'es zero')
