password = input('Introduce la contraseña: ')

if password == '123456':
  print('Bienvenido')
else:
  print('Contraseña incorrecta')


'''
# Si quisiaramos dar una segunda oportunidad, sería:

if password == '123456':
  print('Bienvenido')
else:
  print('Contraseña incorrecta')
  password = input('Segundo y último intento. Introduce la contraseña: ')
  if password == '123456':
    print('Bienvenido')
  else:
    print('Contraseña incorrecta. ¡ADIOS!')
'''
