print('Clasificador de tornillos\n');

medida = float( input('Introduce el tamaño del tornillo en centímetros: ') )

if (medida < 1) or (medida >= 8.5):
  print('Tamaño incorrecto')
elif medida < 3:
  print('Pequeño')
elif medida < 5:
  print('Mediano')
elif medida < 6.5:
  print('Grande')
else:
  print('Muy grande')
