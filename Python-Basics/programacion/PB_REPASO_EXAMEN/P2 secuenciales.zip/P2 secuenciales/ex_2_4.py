# Pedimos los segundos
tiempo = int( input('Introduce un periodo de tiempo expresado en segundos: ') )

# Calculamos los segundos, y el tiempo que quede serán minutos
segundos = tiempo % 60
tiempo = tiempo // 60

# Calculamos los minutos, y el tiempo que quede serán horas
minutos = tiempo % 60
tiempo = tiempo // 60

# Calculamos las horas, y el tiempo que quede serán días
horas = tiempo % 24
dias = tiempo // 24

# Damos los resultados
print('Son', dias, 'días,', horas, 'horas,', minutos, 'minutos y', segundos, 'segundos')
