# Pedimos las notas
n1 = float( input('Introduce la primera nota del alumno: ') )
n2 = float( input('Introduce la segunda nota del alumno: ') )
n3 = float( input('Introduce la tercera nota del alumno: ') )

# Calculamos la media
m = (n1 + n2 + n3) / 3

# Damos el resultado
print('La nota media final es:', m)
