# Pedimos los segundos
tiempo = int( input('Introduce un periodo de tiempo expresado en segundos: ') )

# Calculamos los días y el tiempo que queda en segundos
dias = tiempo // (60*60*24)
tiempo = tiempo % (60*60*24)

# Calculamos las horas y el tiempo que queda en segundos
horas = tiempo // (60*60)
tiempo = tiempo % (60*60)

# Calculamos los minutos y el tiempo que queda son los segundos
minutos = tiempo // 60
segundos = tiempo % 60

# Damos los resultados
print('Son', dias, 'días,', horas, 'horas,', minutos, 'minutos y', segundos, 'segundos')
