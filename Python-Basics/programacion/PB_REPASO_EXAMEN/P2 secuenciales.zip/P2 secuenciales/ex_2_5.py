# Puedo ejecutar comandos del sistema con:
#
#   os.system('comando')
#
#   subprocess.call('comando', shell=True)
#
# Pero para procesar la salida mejor utilizo:
#
#   subprocess.check_output('comando', shell=True).decode('utf-8')
#
# Aviso: usar comandos del sistema hace nuestro programa dependiente de la plataforma

from sys import argv
from subprocess import check_output

pid = argv[1]
proceso    = check_output('ps -q '+pid+' -f', shell=True).decode('utf-8')         # ps -q pid -f
comando    = check_output('ps -q '+pid+' -o cmd h', shell=True).decode('utf-8')   # ps -q pid -o cmd -h
ejecutable = (comando.split(' '))[0]                                              # elimino argumentos
listado    = check_output('ls -l '+ejecutable, shell=True).decode('utf-8')        # ls -l $(ps -q pid -o cmd -h)
print(proceso)
print(listado)



# Mucho más versatil es la librería externa psutil
#
# Para usarla, antes hay que instalar pip y psutil:
#
#   $ sudo apt install python3-pip
#   $ pip3 install psutil
#
# o bien más fácil en algunas distribuciones Linux
#
#   $ sudo apt install python3-psutil

import psutil

p = psutil.Process( int(argv[1]) )
print('nombre:', p.name())
print('inicio de ejecución:', p.create_time())
print('tiempo de ejecución:', p.cpu_times())
print('proceso padre:', p.ppid())
print('estado:', p.status())
