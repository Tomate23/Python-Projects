# Scapy es una librería con la que se pueden construir todo tipo de paquetes de red
#
# Para usarla, antes hay que instalar pip y psutil:
#
#   $ sudo apt install python3-pip
#   $ pip3 install scapy
#
# o bien más fácil en algunas distribuciones Linux
#
#   $ sudo apt install python3-scapy

from scapy.all import *

# Escanea puertos locales 20,21,22,23 . Espera 2 segundos respuesta . Imprime abiertos
resp, no_resp = sr(IP(dst='127.0.0.1')/TCP(sport=RandShort(),dport=[20,21,22,23],flags='S'),timeout=2)
print('---ABIERTOS---')
print(resp.summary())

# Escanea puertos Google del 1 al 100 . Espera 10 segundos respuesta . Imprime abiertos
resp, no_resp = sr(IP(dst='www.google.es')/TCP(sport=RandShort(),dport=(1,100),flags='S'),timeout=10)
print('---ABIERTOS---')
print(resp.summary())
