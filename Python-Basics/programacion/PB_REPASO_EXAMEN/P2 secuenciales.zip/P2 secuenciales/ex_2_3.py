# Pedimos el primer punto
ax = float( input('Introduce la coordenada x del primer punto: ') )
ay = float( input('Introduce la coordenada y del primer punto: ') )

# Pedimos el segundo punto
bx = float( input('Introduce la coordenada x del segundo punto: ') )
by = float( input('Introduce la coordenada y del segundo punto: ') )

# Calculamos el punto medio
mx = (ax + bx) / 2
my = (ay + by) / 2

# Damos los resultados
print('El punto medio es (', mx, ',', my, ')')
