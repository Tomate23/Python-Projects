PI = 3.1416

# Pedimos el radio
r = float( input('Introduce radio del círculo: ') )

# Calculamos el área y perímetro
a = PI * r * r
p = 2 * PI * r

# Damos los resultados
print('Área =', a)
print('Perímetro =', p)
